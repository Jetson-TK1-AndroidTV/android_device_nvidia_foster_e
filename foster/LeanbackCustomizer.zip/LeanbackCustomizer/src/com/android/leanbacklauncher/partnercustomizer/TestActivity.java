package com.google.android.leanbacklauncher.partnercustomizer;

import android.app.Activity;

public class TestActivity extends Activity {

}
